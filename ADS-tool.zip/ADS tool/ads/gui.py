"""A small point-and-click launcher that opens in the browser.

No extra packages, no tkinter: it runs a local web page (only this computer can
reach it) with two choices: the Windows date checks (an NTFS image, or a folder of
parser CSVs) or the first-look report on a FAT or NTFS drive image. Pick one,
press Run, and the plain-language report opens.

    python3 -m ads gui          # opens http://127.0.0.1:8765 in your browser
"""

import json
import os
import secrets
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .config import load_config
from .theme import THEME_CSS, THEME_JS

JOBS = {}
_LOCK = threading.Lock()
# A fresh random token per run. Only the panel page this server sends knows it, and every request
# must carry it, so a web page from another site open in the same browser cannot start a job or
# read results. Requests must also name this computer as their host (blocks DNS rebinding).
TOKEN = secrets.token_urlsafe(24)


def _new_job():
    jid = "j%d" % int(time.time() * 1000)
    JOBS[jid] = {"status": "running", "steps": [], "out": None, "report": None, "proof": None, "error": None}
    return jid


def _step(jid, msg):
    with _LOCK:
        JOBS[jid]["steps"].append(msg)


def _run_ntfs(jid, path):
    """A folder of parser CSVs, or a raw NTFS image read directly (MFT-only rules)."""
    from . import pipeline
    cfg = load_config(None)
    is_image = os.path.isfile(path)
    out = (os.path.splitext(path)[0] + " Windows report") if is_image else os.path.join(path, "ADS report")
    db = os.path.join(out, "case.sqlite")
    os.makedirs(out, exist_ok=True)
    try:
        if is_image:
            _step(jid, "Reading the file table (MFT) straight from the image")
            summary = pipeline.ingest_image(path, db, cfg)
        else:
            _step(jid, "Reading the records in that folder")
            summary = pipeline.ingest_folder(path, db, cfg)
        _step(jid, "Loaded " + ", ".join("%s (%d rows)" % (s["kind"], s["rows"]) for s in summary))
        _step(jid, "Cross-checking the records")
        r = pipeline.analyze_db(db, out, cfg, self_calibrate=True)
        _step(jid, "Checked %d files; flagged %d" % (r["scored"], r["flagged"]))
        _finish(jid, out, os.path.join(out, "briefing.html"))
    except Exception as e:
        _fail(jid, str(e))


def _run_image(jid, image, key=""):
    """First-look report on a FAT or NTFS drive image: the eight questions; optionally a proof page."""
    from .briefing import write_triage
    from .triage import Triage, UnsupportedImage
    out = os.path.splitext(image)[0] + " report"
    try:
        _step(jid, "Opening the drive image")
        t = Triage(image)
        _step(jid, "Opened the drive (%s). Reading files and asking eight questions of each" % t.vol.summary()["fs_type"])
        t.collect().run()
        data, html = write_triage(t, out)
        t.close()
        _step(jid, "Checked %d files; %d had a clue" % (data["counts"]["examined"], data["counts"]["with_findings"]))
        if key:
            from . import proof
            _, summ = proof.write(out, key)
            _step(jid, "Compared with your answer key: %d of %d evidence files are on the list (%d in the top 10)"
                  % (summ["found"], summ["evidence"], summ["top10"]))
            with _LOCK:
                JOBS[jid]["proof"] = True
        _finish(jid, out, html)
    except UnsupportedImage as e:
        _fail(jid, "%s ADS reads raw images (.img, .dd, .raw) of FAT and NTFS drives." % e)
    except Exception as e:
        _fail(jid, str(e))


def _finish(jid, out, report):
    with _LOCK:
        JOBS[jid].update(status="done", out=out, report=report)


def _fail(jid, msg):
    with _LOCK:
        JOBS[jid].update(status="error", error=msg)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        body = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        port = self.server.server_address[1]
        return self.headers.get("Host", "") in ("127.0.0.1:%d" % port, "localhost:%d" % port)

    def _token_ok(self, given):
        return secrets.compare_digest(given or "", TOKEN)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, "forbidden")
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/":
            return self._send(200, PAGE.replace("@TOKEN@", TOKEN).replace("@css@", THEME_CSS).replace("@js@", THEME_JS))
        if not self._token_ok(q.get("t", [""])[0]):
            return self._send(403, "forbidden")
        if u.path == "/status":
            jid = q.get("job", [""])[0]
            job = JOBS.get(jid)
            if not job:
                return self._send(404, "{}", "application/json")
            view = {"status": job["status"], "steps": job["steps"], "error": job["error"],
                    "report": ("/report?job=%s&f=briefing.html&t=%s" % (jid, TOKEN)) if job["report"] else None,
                    "proof": ("/report?job=%s&f=proof.html&t=%s" % (jid, TOKEN)) if job["proof"] and job["report"] else None,
                    "folder": job["out"]}
            return self._send(200, json.dumps(view), "application/json")
        if u.path == "/report":
            jid = q.get("job", [""])[0]
            job = JOBS.get(jid)
            if not job or not job["out"]:
                return self._send(404, "not found")
            name = os.path.basename(q.get("f", ["briefing.html"])[0])
            path = os.path.join(job["out"], name)
            if not os.path.isfile(path):
                return self._send(404, "not found")
            ctype = "text/html; charset=utf-8" if name.endswith(".html") else "application/octet-stream"
            with open(path, "rb") as fh:
                return self._send(200, fh.read(), ctype)
        self._send(404, "not found")

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, "forbidden")
        if self.path != "/run":
            return self._send(404, "not found")
        length = int(self.headers.get("Content-Length", 0))
        data = urllib.parse.parse_qs(self.rfile.read(length).decode("utf-8"))
        if not self._token_ok(data.get("t", [""])[0]):
            return self._send(403, "forbidden")
        kind = data.get("kind", [""])[0]
        path = data.get("path", [""])[0].strip().strip('"').strip("'")
        if kind == "ntfs" and not os.path.exists(path):
            return self._send(200, json.dumps({"error": "That folder or image was not found: %s" % path}), "application/json")
        if kind == "fat" and not os.path.isfile(path):
            return self._send(200, json.dumps({"error": "That image file was not found: %s" % path}), "application/json")
        key = data.get("key", [""])[0].strip().strip('"').strip("'")
        if kind == "fat" and key and not os.path.isfile(key):
            return self._send(200, json.dumps({"error": "That answer key file was not found: %s" % key}), "application/json")
        jid = _new_job()
        if kind == "ntfs":
            threading.Thread(target=_run_ntfs, args=(jid, path), daemon=True).start()
        else:
            threading.Thread(target=_run_image, args=(jid, path, key), daemon=True).start()
        self._send(200, json.dumps({"job": jid}), "application/json")


def main(argv=None):
    port = 8765
    if argv:
        try:
            port = int(argv[0])
        except ValueError:
            pass
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = "http://127.0.0.1:%d" % port
    print("ADS control panel is open at %s" % url)
    print("Leave this window open while you use it. Press Ctrl+C here to close.")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nClosed.")


PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>ADS Control Panel</title>
<style>@css@
label{display:block;font-weight:600;margin:12px 0 5px;font-size:13px;color:var(--muted)}
input[type=text]{width:100%;padding:10px 12px;border:1px solid var(--line2);border-radius:8px;font:14px var(--mono);background:var(--panel2);color:var(--text)}
input[type=text]:focus{outline:none;border-color:var(--accent)}
.run{font:700 14px var(--ui);border:0;border-radius:8px;padding:11px 18px;background:var(--accent);color:#06121f;cursor:pointer;margin-top:14px;
  display:inline-flex;gap:8px;align-items:center}
.run:hover{filter:brightness(1.1)}
.card h2{font-size:18px;display:flex;gap:10px;align-items:center}
.card .lead{color:var(--muted);font-size:14px;margin-top:6px}
#log{margin-top:16px;background:#060a14;border:1px solid var(--line);border-radius:12px;padding:14px;font:13px/1.7 var(--mono);color:#cfe8ff;min-height:70px}
#log:empty::before{content:"> waiting for a job";color:var(--dim)}
.step::before{content:"> ";color:var(--accent)}
.err{color:var(--hot)}.done{color:var(--ok)}
a.open{display:inline-block;margin:10px 16px 0 0;font:700 14px var(--ui);color:var(--accent-ink)}
.spin{display:inline-block;width:12px;height:12px;border:2px solid var(--accent);border-top-color:transparent;border-radius:50%;animation:s .8s linear infinite;vertical-align:-1px;margin-right:6px}
@keyframes s{to{transform:rotate(360deg)}}
</style></head><body>
<header class="top"><div class="wrap"><div class="brand"><span class="dot"></span>ADS // CONTROL PANEL</div>
<div class="case"><span class="pill">read-only · this computer only</span></div><div class="spacer"></div>
<button class="iconbtn" data-act="theme" title="Light or dark"><svg class="ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></button></div></header>
<main class="wrap">
<div class="ph"><div><h2>Point the tool at a drive</h2><div class="sub">It reads the drive without changing it and opens a report.</div></div></div>
<div class="grid g2">
<div class="card">
<h2><svg class="ico" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 15h.01M10 15h8M6 9h12"/></svg>First look at a drive image</h2>
<p class="lead">Eight questions of every file: disguised, hidden, locked, password written down… FAT or NTFS (.img, .dd, .raw).</p>
<label for="fat">Drive image</label>
<input type="text" id="fat" placeholder="C:\Cases\26Fall_Project2.img">
<label for="key">Optional: your own findings to compare with (answer key .csv)</label>
<input type="text" id="key" placeholder="proof\project2_answer_key.csv">
<button class="run" onclick="run('fat','fat')">Run first look ›</button>
</div>
<div class="card">
<h2><svg class="ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Windows date checks</h2>
<p class="lead">Compares the dates Windows keeps in different places. An NTFS image, or the folder made by scripts/run_parsers.ps1 (adds more records).</p>
<label for="ntfs">NTFS image, or folder of record files</label>
<input type="text" id="ntfs" placeholder="C:\Cases\Case01\parsed">
<button class="run" onclick="run('ntfs','ntfs')">Run date checks ›</button>
</div></div>
<div id="log"></div>
</main>
<script>
const TOKEN='@TOKEN@';
let timer=null;
function el(t,c,h){let e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function run(kind,inputId){
  let path=document.getElementById(inputId).value;
  let log=document.getElementById('log');log.innerHTML='';
  if(!path){log.appendChild(el('div','step err','Please enter a path first.'));return}
  log.appendChild(el('div','step','<span class="spin"></span>Starting…'));
  fetch('/run',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'kind='+encodeURIComponent(kind)+'&path='+encodeURIComponent(path)+'&t='+TOKEN+
      (kind==='fat'?'&key='+encodeURIComponent(document.getElementById('key').value):'')})
   .then(r=>r.json()).then(d=>{
     if(d.error){log.innerHTML='';log.appendChild(el('div','step err',d.error));return}
     poll(d.job);
   });
}
function poll(job){
  if(timer)clearInterval(timer);
  timer=setInterval(()=>{
    fetch('/status?job='+job+'&t='+TOKEN).then(r=>r.json()).then(d=>{
      let log=document.getElementById('log');log.innerHTML='';
      d.steps.forEach(s=>log.appendChild(el('div','step',s)));
      if(d.status==='running')log.appendChild(el('div','step','<span class="spin"></span>Working…'));
      if(d.status==='error'){clearInterval(timer);log.appendChild(el('div','step err',d.error))}
      if(d.status==='done'){clearInterval(timer);
        let done=el('div','step done','Done. The report is saved in: '+d.folder);
        log.appendChild(done);
        let a=el('a','open','Open the report ›');a.href=d.report;a.target='_blank';
        log.appendChild(a);
        if(d.proof){let b=el('a','open','Open the comparison with your findings ›');b.href=d.proof;b.target='_blank';log.appendChild(b);}
      }
    });
  },600);
}
</script>
<script>@js@</script>
</body></html>"""
